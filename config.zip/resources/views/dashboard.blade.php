<x-layout>
  <div class="grid grid-cols-4 gap-4 h-32">
    <x-card class="">
      <p>Total Income</p>
      <span>Rs. 300</span>
    </x-card>
    <x-card >hi</x-card>
    <x-card ></x-card>
    <x-card ></x-card>
  </div>
</x-layout>