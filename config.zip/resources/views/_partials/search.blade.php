<div class="w-full flex flex-col mb-4 relative">
    <input type="search" name="search" id="search" class="search" placeholder="Search" autocomplete="off">
    <ul class="w-full absolute z-20 top-14" id="results">
    </ul>
</div>
