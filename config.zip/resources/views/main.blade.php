@auth
<x-layout>
   
</x-layout>
@else
@php

@endphp
@endauth