<div {{$attributes->merge(['class' => 'bg-gray-200 rounded-lg flex items-center p-4'])}}>
  {{$slot}}
 </div>